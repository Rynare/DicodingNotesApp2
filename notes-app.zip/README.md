Link website [NotesApp Basic - Klik](https://rynare.github.io/dicoding_submission-notesApp/)
